from map import create_network
from GUILinux import Window

G = create_network()
Window(G)
