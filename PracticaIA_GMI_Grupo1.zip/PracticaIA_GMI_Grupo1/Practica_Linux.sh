python3 --version
if [ $? -eq 0 ]
then
	sudo apt-get install python3-pip -y
	sudo apt-get install python3-venv -y
	python3 -m venv myvenv
	./myvenv/bin/pip3 install -r ./src/requirements.txt
	sudo apt-get install python3-tk -y
	./myvenv/bin/python3 ./src/mainLinux.py
else
	sudo apt-get install python-pip -y
	sudo apt-get install python-venv -y
	./myvenv/bin/pip install -r ./src/requirements.txt
	./myvenv/bin/pip install tkinter -y
	./myvenv/bin/python ./src/mainLinux.py
fi
